"""Первичная настройка: сохраняет конфигурацию и создаёт БД/таблицу."""
from configparser import ConfigParser
from getpass import getpass
from pathlib import Path
import sys

try:
    import psycopg
    from psycopg import sql
except ImportError:
    print("Не установлен Psycopg. Выполните: python -m pip install -r requirements.txt")
    raise SystemExit(1)

ROOT = Path(__file__).resolve().parent
DB_NAME = "organic_chemistry"

def main():
    print("=" * 58)
    print("НАСТРОЙКА ПРОЕКТА «ОРГАНИЧЕСКАЯ ХИМИЯ»")
    print("=" * 58)
    host = input("Сервер PostgreSQL [localhost]: ").strip() or "localhost"
    port_text = input("Порт PostgreSQL [5432]: ").strip() or "5432"
    user = input("Пользователь PostgreSQL [postgres]: ").strip() or "postgres"
    password = getpass("Пароль PostgreSQL: ")
    if not password:
        print("Пароль не может быть пустым.")
        raise SystemExit(1)
    try:
        port = int(port_text)
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        print("Порт должен быть числом от 1 до 65535.")
        raise SystemExit(1)

    admin = dict(host=host, port=port, user=user, password=password,
                 dbname="postgres", connect_timeout=5)
    print("\nПодключение к PostgreSQL...")
    try:
        with psycopg.connect(**admin, autocommit=True) as conn:
            exists = conn.execute(
                "SELECT 1 FROM pg_database WHERE datname = %s", (DB_NAME,)
            ).fetchone()
            if not exists:
                conn.execute(
                    sql.SQL("CREATE DATABASE {}").format(sql.Identifier(DB_NAME))
                )
                print(f"Создана база данных {DB_NAME}.")
            else:
                print(f"База данных {DB_NAME} уже существует.")

        app_config = dict(host=host, port=port, user=user, password=password,
                          dbname=DB_NAME, connect_timeout=5)
        with psycopg.connect(**app_config) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS public.alkanes (
                    name TEXT PRIMARY KEY,
                    formula TEXT NOT NULL,
                    carbon_count INTEGER NOT NULL CHECK (carbon_count > 0)
                )
            """)
            rows = [
                ("Метан", "CH4", 1), ("Этан", "C2H6", 2),
                ("Пропан", "C3H8", 3), ("Бутан", "C4H10", 4),
                ("Пентан", "C5H12", 5), ("Гексан", "C6H14", 6),
                ("Гептан", "C7H16", 7), ("Октан", "C8H18", 8),
                ("Нонан", "C9H20", 9), ("Декан", "C10H22", 10),
            ]
            conn.executemany("""
                INSERT INTO public.alkanes (name, formula, carbon_count)
                VALUES (%s, %s, %s)
                ON CONFLICT (name) DO UPDATE SET
                    formula = EXCLUDED.formula,
                    carbon_count = EXCLUDED.carbon_count
            """, rows)
            count = conn.execute("SELECT COUNT(*) FROM public.alkanes").fetchone()[0]

        parser = ConfigParser()
        parser["postgresql"] = {
            "dbname": DB_NAME, "user": user, "password": password,
            "host": host, "port": str(port), "connect_timeout": "5"
        }
        config_path = ROOT / "db_config.ini"
        with config_path.open("w", encoding="utf-8") as file:
            parser.write(file)
        try:
            config_path.chmod(0o600)
        except OSError:
            pass

        print(f"\nГотово! В таблице public.alkanes записей: {count}.")
        print("Настройки сохранены в db_config.ini.")
        print("Теперь запустите: python gui_database.py")
    except psycopg.Error as error:
        print("\nНе удалось настроить базу данных.")
        print(f"Подробности PostgreSQL: {error}")
        print("Проверьте, что сервер PostgreSQL запущен, а логин и пароль верны.")
        raise SystemExit(1)

if __name__ == "__main__":
    main()
