"""Занятие 2: чтение данных PostgreSQL из Python."""
import psycopg
from db_config import get_db_config

def main():
    with psycopg.connect(**get_db_config()) as conn:
        rows = conn.execute("""
            SELECT name, formula, carbon_count
            FROM public.alkanes ORDER BY carbon_count
        """).fetchall()
    print(f"Подключение успешно. Записей: {len(rows)}")
    print(f"{'Название':<15} {'Формула':<10} {'Атомов C':>10}")
    print("-" * 39)
    for name, formula, carbon_count in rows:
        print(f"{name:<15} {formula:<10} {carbon_count:>10}")

if __name__ == "__main__":
    try:
        main()
    except (psycopg.Error, OSError, ValueError) as error:
        print(f"Ошибка: {error}")
        print("Сначала выполните python setup_project.py")
