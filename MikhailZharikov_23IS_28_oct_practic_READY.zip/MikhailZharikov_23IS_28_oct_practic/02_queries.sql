-- Занятие 2. Все запросы из практической работы.

-- Исходная выборка: все десять алканов.
SELECT name, formula, carbon_count
FROM public.alkanes
ORDER BY carbon_count ASC;

-- Найти пропан.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE name = 'Пропан'
ORDER BY carbon_count ASC;

-- Самостоятельно: найти метан.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE name = 'Метан'
ORDER BY carbon_count ASC;

-- Не больше четырёх атомов углерода.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE carbon_count <= 4
ORDER BY carbon_count ASC;

-- Больше семи атомов углерода.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE carbon_count > 7
ORDER BY carbon_count ASC;

-- От 3 до 6 включительно: вариант с AND.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE carbon_count >= 3 AND carbon_count <= 6
ORDER BY carbon_count ASC;

-- Тот же диапазон: вариант с BETWEEN.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE carbon_count BETWEEN 3 AND 6
ORDER BY carbon_count ASC;

-- Тот же диапазон по убыванию.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE carbon_count BETWEEN 3 AND 6
ORDER BY carbon_count DESC;

-- Сортировка названий по алфавиту.
SELECT name, formula, carbon_count
FROM public.alkanes
ORDER BY name ASC;

-- Самостоятельные задания:
-- 1. Название и формула бутана.
SELECT name, formula
FROM public.alkanes
WHERE name = 'Бутан';

-- 2. От 5 до 8 атомов, по возрастанию.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE carbon_count BETWEEN 5 AND 8
ORDER BY carbon_count ASC;

-- 3. Не меньше 8 атомов, по убыванию.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE carbon_count >= 8
ORDER BY carbon_count DESC;

-- 4. Найти вещество по формуле C2H6.
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE formula = 'C2H6';

-- 5. Больше 20 атомов (ожидается пустой результат).
SELECT name, formula, carbon_count
FROM public.alkanes
WHERE carbon_count > 20;
