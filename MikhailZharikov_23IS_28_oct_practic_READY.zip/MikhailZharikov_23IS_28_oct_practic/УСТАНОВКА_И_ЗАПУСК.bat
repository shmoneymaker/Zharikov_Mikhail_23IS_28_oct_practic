@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Установка библиотеки Psycopg...
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo Не удалось установить зависимости. Проверьте Python и интернет.
  pause
  exit /b 1
)
py run_project.py
pause
