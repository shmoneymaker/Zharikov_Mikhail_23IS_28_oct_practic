"""Графический каталог алканов с поиском и фильтром (Tkinter + PostgreSQL)."""
import tkinter as tk
from tkinter import ttk, messagebox
import psycopg
from db_config import get_db_config

class AlkaneApp:
    def __init__(self, root):
        self.root = root
        root.title("Органическая химия — каталог алканов")
        root.geometry("760x500")
        root.minsize(620, 400)

        header = ttk.Label(root, text="Каталог алканов",
                           font=("Arial", 18, "bold"))
        header.pack(pady=(16, 8))

        controls = ttk.Frame(root, padding=(14, 4))
        controls.pack(fill="x")
        ttk.Label(controls, text="Поиск:").pack(side="left")
        self.search_var = tk.StringVar()
        search = ttk.Entry(controls, textvariable=self.search_var, width=28)
        search.pack(side="left", padx=8)
        search.bind("<Return>", lambda _event: self.load_data())
        ttk.Button(controls, text="Найти / обновить",
                   command=self.load_data).pack(side="left", padx=3)
        ttk.Button(controls, text="Показать все",
                   command=self.show_all).pack(side="left", padx=3)
        ttk.Button(controls, text="Очистить",
                   command=self.clear_table).pack(side="left", padx=3)

        table_frame = ttk.Frame(root, padding=14)
        table_frame.pack(fill="both", expand=True)
        columns = ("name", "formula", "carbon_count")
        self.table = ttk.Treeview(table_frame, columns=columns,
                                  show="headings", height=13)
        self.table.heading("name", text="Название")
        self.table.heading("formula", text="Формула")
        self.table.heading("carbon_count", text="Атомов углерода")
        self.table.column("name", width=260, anchor="w")
        self.table.column("formula", width=160, anchor="center")
        self.table.column("carbon_count", width=180, anchor="center")
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical",
                                  command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set)
        self.table.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.status = tk.StringVar(value="Нажмите «Показать все» для загрузки данных.")
        ttk.Label(root, textvariable=self.status, anchor="w",
                  padding=(14, 4)).pack(fill="x")
        root.bind("<Control-r>", lambda _event: self.load_data())
        self.load_data()

    def clear_table(self):
        for item in self.table.get_children():
            self.table.delete(item)
        self.status.set("Таблица очищена. Данные в базе не удалены.")

    def show_all(self):
        self.search_var.set("")
        self.load_data()

    def load_data(self):
        term = self.search_var.get().strip()
        try:
            with psycopg.connect(**get_db_config()) as conn:
                if term:
                    rows = conn.execute("""
                        SELECT name, formula, carbon_count
                        FROM public.alkanes
                        WHERE name ILIKE %s OR formula ILIKE %s
                        ORDER BY carbon_count
                    """, (f"%{term}%", f"%{term}%")).fetchall()
                else:
                    rows = conn.execute("""
                        SELECT name, formula, carbon_count
                        FROM public.alkanes ORDER BY carbon_count
                    """).fetchall()
            self.clear_table()
            for row in rows:
                self.table.insert("", tk.END, values=row)
            self.status.set(f"Найдено записей: {len(rows)}")
        except (psycopg.Error, OSError, ValueError) as error:
            messagebox.showerror(
                "Ошибка подключения",
                f"{error}\n\nЗапустите setup_project.py и проверьте PostgreSQL."
            )
            self.status.set("Не удалось загрузить данные.")

def main():
    root = tk.Tk()
    AlkaneApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
