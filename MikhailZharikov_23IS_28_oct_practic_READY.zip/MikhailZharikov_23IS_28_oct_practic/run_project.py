"""Первичная настройка при необходимости, затем запуск графического приложения."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
config = root / "db_config.ini"
if not config.exists():
    print("Первый запуск: настройка PostgreSQL.")
    result = subprocess.call([sys.executable, str(root / "setup_project.py")])
    if result != 0:
        raise SystemExit(result)
raise SystemExit(subprocess.call([sys.executable, str(root / "gui_database.py")]))
