-- Выполнять в Query Tool базы postgres при включённом Auto commit.
-- Если база уже существует, PostgreSQL сообщит об этом; это не ошибка проекта.
CREATE DATABASE organic_chemistry;
