# Органическая химия — каталог алканов

Готовый учебный проект по четырём занятиям: PostgreSQL, SQL, Python/Psycopg 3 и графический интерфейс Tkinter.

## Что реализовано

1. Создание базы `organic_chemistry`.
2. Таблица `public.alkanes` с тремя столбцами: `name`, `formula`, `carbon_count`.
3. Десять алканов от метана до декана.
4. SQL-запросы: `SELECT`, `WHERE`, `AND`, `BETWEEN`, `ORDER BY`, `ASC`, `DESC`.
5. Получение данных из PostgreSQL в Python.
6. Два окна Tkinter: учебное окно с ручными данными и окно, связанное с PostgreSQL.
7. Поиск по названию/формуле, обновление, показ всех записей и очистка отображения.
8. Автоматическая первичная настройка базы и файла подключения.

## Что нужно установить

- Python 3.10 или новее;
- PostgreSQL Server (сервер должен быть запущен);
- на Windows — Python с Tkinter (обычный установщик python.org подходит).

pgAdmin 4 необязателен для запуска программы, но удобен для просмотра базы и выполнения SQL-запросов.

## Быстрый запуск на Windows

1. Установите и запустите PostgreSQL Server.
2. Распакуйте весь архив в отдельную папку.
3. Дважды нажмите `УСТАНОВКА_И_ЗАПУСК.bat`.
4. При первом запуске введите сервер (обычно `localhost`), порт (обычно `5432`), пользователя (обычно `postgres`) и пароль, который задавали при установке PostgreSQL.
5. Скрипт создаст базу `organic_chemistry`, таблицу, заполнит её десятью алканами и сохранит настройки.
6. Откроется графическое приложение.

При последующих запусках используйте `run_project.py` или снова `УСТАНОВКА_И_ЗАПУСК.bat`.

## Запуск вручную

Откройте терминал в папке проекта:

```bash
python -m pip install -r requirements.txt
python setup_project.py
python gui_database.py
```

Консольный вариант:

```bash
python console_alkanes.py
```

Учебное окно третьего занятия (не требует подключения к БД):

```bash
python gui_manual.py
```

Проверка Tkinter:

```bash
python -m tkinter
```

## SQL-файлы и pgAdmin

- `00_database.sql` — команда создания базы. Её выполняют в Query Tool базы `postgres` с включённым Auto commit. Если база уже существует, повторно выполнять не нужно.
- `01_alkanes.sql` — создание таблицы и заполнение данными. Выполняется в Query Tool базы `organic_chemistry`. Скрипт безопасно запускать повторно.
- `02_queries.sql` — примеры и самостоятельные запросы из занятия 2. Запускайте запросы по одному в базе `organic_chemistry`.

Проверка результата:

```sql
SELECT current_database();
SELECT name, formula, carbon_count FROM public.alkanes ORDER BY carbon_count;
SELECT COUNT(*) FROM public.alkanes;
```

Ожидается база `organic_chemistry` и 10 записей.

## Файлы проекта

| Файл | Назначение |
|---|---|
| `setup_project.py` | Автоматическое создание БД, таблицы и настроек подключения |
| `run_project.py` | Удобный запуск приложения |
| `00_database.sql` | SQL для создания базы |
| `01_alkanes.sql` | Таблица и десять алканов |
| `02_queries.sql` | SQL-запросы и самостоятельные задания |
| `console_alkanes.py` | Вывод данных в консоль |
| `gui_manual.py` | Tkinter с тремя ручными записями |
| `gui_database.py` | Tkinter + PostgreSQL, поиск и обновление |
| `db_config.py` | Чтение параметров подключения |
| `db_config.example.ini` | Пример настроек |
| `requirements.txt` | Зависимость Psycopg 3 |
| `УСТАНОВКА_И_ЗАПУСК.bat` | Установка зависимости и запуск на Windows |

## Возможные ошибки

- `connection refused` — PostgreSQL Server не запущен или указан неверный порт.
- `password authentication failed` — неверный пароль или имя пользователя.
- `No module named psycopg` — выполните `python -m pip install -r requirements.txt`.
- `No module named tkinter` — установите Python-компонент Tcl/Tk.
- Если изменили пароль PostgreSQL, удалите локальный `db_config.ini` и повторно запустите `setup_project.py`.

Файл `db_config.ini` создаётся автоматически и исключён из Git, так как содержит пароль. Не публикуйте его.

## Важно о проверке

Python-файлы можно проверить без подключения к PostgreSQL, но полноценный запуск базы и графического окна выполняется на компьютере с установленным PostgreSQL и Tkinter. Пароль PostgreSQL не включён в архив — его нужно ввести при первой настройке.
