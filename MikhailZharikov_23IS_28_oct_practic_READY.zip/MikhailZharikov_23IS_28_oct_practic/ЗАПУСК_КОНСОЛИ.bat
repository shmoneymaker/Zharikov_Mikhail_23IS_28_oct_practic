@echo off
chcp 65001 >nul
cd /d "%~dp0"
py console_alkanes.py
pause
