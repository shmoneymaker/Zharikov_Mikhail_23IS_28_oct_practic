"""Загрузка настроек подключения к PostgreSQL."""
from configparser import ConfigParser
from pathlib import Path

CONFIG_FILE = Path(__file__).with_name("db_config.ini")

def get_db_config():
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            "Не найден db_config.ini. Сначала запустите setup_project.py."
        )
    parser = ConfigParser()
    parser.read(CONFIG_FILE, encoding="utf-8")
    if "postgresql" not in parser:
        raise ValueError("В db_config.ini отсутствует секция [postgresql].")
    config = dict(parser["postgresql"])
    config["port"] = int(config.get("port", "5432"))
    config["connect_timeout"] = int(config.get("connect_timeout", "5"))
    if not config.get("password") or config["password"] == "CHANGE_ME":
        raise ValueError("В db_config.ini не указан пароль PostgreSQL.")
    return config
